package com.example.fyp_student.Class;

public class Material {
    String fileName;

    public Material(String fileName) {
        this.fileName = fileName;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }
}
